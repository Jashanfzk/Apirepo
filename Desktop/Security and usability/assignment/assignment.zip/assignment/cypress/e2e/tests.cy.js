describe('Jasmine Assignment (part 1)', () => {
    beforeEach(() => {
        cy.visit('/exercise/part1/part1.html');
        Cypress.Screenshot.defaults({screenshotOnRunFailure: false});
    });
    describe("Initial Page Load", () => {
        it('form should have "novalidate" attribute', () => {
            cy.get('form').should('have.attr', 'novalidate');
        });
        [
            { selector: 'check_number', label: 'Number' },
        ].forEach(({ selector, label }) => {
            describe(`${selector}`, () => {
                it(`#${selector} element should have label "${label}"`, () => {
                    cy.get(`label[for="${selector}"]`).first().invoke('text').then(text => assert.equal(text.replace(/['"]/g, '').trim(), label))
                });
                it(`#${selector} should have correct type`, () => {
                    cy.get(`#${selector}`).should('have.attr', 'type', 'text');
                });
                it(`#${selector} should have name attribute`, () => {
                    cy.get(`#${selector}`)
                        .should('have.attr', 'name')
                        .and('not.be.empty');
                });
            });
        });
    });
    describe('Validation', () => {
        describe('Number input', () => {
            it(`should style field #check_number with red border color (rgb(255, 0, 0)) if field is empty and form is submitted`, () => {
                cy.get(`#check_number`).clear()
                cy.get('input[type="submit"], button[type="submit"]').click();
                cy.get(`#check_number`).should('have.css', 'border-color')
                    .and('equal', 'rgb(255, 0, 0)');
            });

            it(`should reset field #check_number to valid after it was invalid and got correct input (87)`, () => {
                cy.get('input[type="submit"], button[type="submit"]').click();
                cy.get(`#check_number`).clear().type('87');
                cy.get('input[type="submit"], button[type="submit"]').click();
                cy.get(`#check_number`).should('have.css', 'border-color')
                    .and('not.equal', 'rgb(255, 0, 0)');
            });
            ['17', 'in val id', '&$#', 'John!'].forEach(i => {
                it(`should mark field #check_number as invalid if user types '${i}'`, () => {
                    cy.get('#check_number').type(`${i}`);
                    cy.get('input[type="submit"], button[type="submit"]').click();
                    cy.get(`#check_number`).should('have.css', 'border-color')
                        .and('equal', 'rgb(255, 0, 0)');
                });
            });
        });
    });
    describe('Check Number', () => {
        const missingInput = 'Missing input';
        const wrongNumber = 'Wrong number';
        const isLessMessage = 'Your number is less than secret. Try again.';
        const isMoreMessage = 'Your number is more than secret. Try again.';
        const congratulations = 'Congratulations!';
        [
            { value: 'not a number', expected: missingInput },
            { value: 16, expected: wrongNumber },
            { value: 17, expected: isLessMessage },
            { value: 18, expected: isLessMessage },
            { value: 98, expected: isMoreMessage },
            { value: 99, expected: isMoreMessage },
            { value: 100, expected: wrongNumber },
            { value: 87, expected: congratulations },
        ].forEach(({ value, expected }) => {
            it(`should display "${expected}" if value is ${value}`, () => {
                cy.get(`#check_number`).clear().type(value);
                cy.get('input[type="submit"], button[type="submit"]').click();
                cy.get('#result').contains(expected).should('exist');
            });
        });
    });
});
describe('Form (part2)', () => {
    beforeEach(() => {
        cy.visit('/exercise/part2/part2.html');
        Cypress.Screenshot.defaults({screenshotOnRunFailure: false});
    });
    describe("Initial Page Load", () => {
        it("should hide the #welcome_message section visually", () => {
            cy.get("#welcome_message").should("not.be.visible");
        });
        it('form should have "novalidate" attribute', () => {
            cy.get('form').should('have.attr', 'novalidate');
        });
        [
            { selector: 'username_input', label: 'Username' },
            { selector: 'password_input', label: 'Password' },
        ].forEach(({ selector, label }) => {
            describe(`${selector}`, () => {
                it(`#${selector} element should have label "${label}"`, () => {
                    cy.get(`label[for="${selector}"]`).first().invoke('text').then(text => assert.equal(text.replace(/['"]/g, '').trim(), label))
                });
                it(`#${selector} should have correct type`, () => {
                    cy.get(`#${selector}`).should('have.attr', 'type', 'text');
                });
                it(`#${selector} should have necessary attribute`, () => {
                    cy.get(`#${selector}`)
                        .should('have.attr', 'name')
                        .and('not.be.empty');
                });
            });
        });
    });
    describe("Valid inputs", () => {
        beforeEach(() => {
            cy.get("#username_input").type("John_Mike");
        });
        it("should show #welcome_message for correct password", () => {
            cy.get("#password_input").type("r8g#(0ASD@%");
            cy.get('input[type="submit"], button[type="submit"]').click();
            cy.get("#welcome_message").should('be.visible');
            cy.get("#welcome_message").should("contain", "Your password is correct");
        });
        it("should show #welcome_message for incorrect password", () => {
            cy.get("#password_input").type("123");
            cy.get('input[type="submit"], button[type="submit"]').click();
            cy.get("#welcome_message").should('be.visible');
            cy.get("#welcome_message").should("contain", "Your password is incorrect");
        });
    });

    describe('Validation', () => {
        describe('Username input', () => {
            it(`should style field #username_input with red border color (rgb(255, 0, 0)) if field is empty and form is submitted`, () => {
                cy.get(`#username_input`).clear()
                cy.get('input[type="submit"], button[type="submit"]').click();
                cy.get(`#username_input`).should('have.css', 'border-color')
                    .and('equal', 'rgb(255, 0, 0)');
            });

            it(`should reset field #username_input to valid after it was invalid and got correct input`, () => {
                cy.get('input[type="submit"], button[type="submit"]').click();

                cy.get(`#username_input`).clear().type('Valid');

                cy.get('input[type="submit"], button[type="submit"]').click();

                cy.get(`#username_input`).should('have.css', 'border-color')
                    .and('not.equal', 'rgb(255, 0, 0)');
            });
            ['in val id', '&$#', 'John!'].forEach(i => {
                it(`should mark field #username_input as invalid if user types '${i}'`, () => {
                    cy.get('#username_input').type(`${i}`);
                    cy.get('input[type="submit"], button[type="submit"]').click();
                    cy.get(`#username_input`).should('have.css', 'border-color')
                        .and('equal', 'rgb(255, 0, 0)');
                });
            });
        });

        describe('Password input', () => {
            it(`should style field #password_input with red border color (rgb(255, 0, 0)) if field is empty and form is submitted`, () => {
                cy.get(`#password_input`).clear()
                cy.get('input[type="submit"], button[type="submit"]').click();
                cy.get(`#password_input`).should('have.css', 'border-color')
                    .and('equal', 'rgb(255, 0, 0)');
            });

            it(`should reset field #password_input to valid after it was invalid and got correct input`, () => {
                cy.get('input[type="submit"], button[type="submit"]').click();

                cy.get(`#password_input`).clear().type('12345');

                cy.get('input[type="submit"], button[type="submit"]').click();

                cy.get(`#password_input`).should('have.css', 'border-color')
                    .and('not.equal', 'rgb(255, 0, 0)');
            });
            ['8a.7', '1 2 3', '&$-#'].forEach(i => {
                it(`should mark field #password_input as invalid if user types '${i}'`, () => {
                    cy.get('#password_input').type(`${i}`);
                    cy.get('input[type="submit"], button[type="submit"]').click();
                    cy.get(`#password_input`).should('have.css', 'border-color')
                        .and('equal', 'rgb(255, 0, 0)');
                });
            });
        });

        it(`should not show the #welcome_message if any of the field is empty`, () => {
            cy.get('input[type="submit"], button[type="submit"]').click();
            cy.get('#welcome_message').should('not.be.visible');
        });

    });
});