﻿window.onload=function(){
	const form=document.getElementById("login_form");
	const usernameInput=document.getElementById("username_input");
	const passwordInput=document.getElementById("password_input");
	const welcomeMessage=document.getElementById("welcome_message");

	const correctPassword="r8g#(0ASD@%";

	form.addEventListener("submit", async function (event){
		event.preventDefault();

		const username= usernameInput.value.trim();
		const password= passwordInput.value.trim();

		let isvalid = true;

		const usernameregex= /^[a-zA-Z0-9_]+$/;
		if(!usernameregex.test(username)){
			usernameInput.style.borderColor="rgb(255, 0, 0)";
			isvalid=false;
		}else{
			usernameInput.style.bordercolor="";
		}
		const passwordRegax= /^[^\s.-]+$/;
		if(!passwordRegax.test(password)){
			passwordInput.style.borderColor="rgb(255, 0, 0)";
			isvalid=false;
		}else{
			passwordInput.style.bordercolor="";
		}
		if(isvalid){
			const correctHash=await generateHash(correctPassword)
			const userHash = await generateHash(password);
			if (userHash === correctHash){
				welcomeMessage.textContent = "Your Password is correct";

			}else{
				welcomeMessage.textContent="Your password is incorrect";
			}
		}else{
				welcomeMessage.textContent="";
			}

			});
		}


	

