window.onload=function(){
	const form=document.getElementById("numberForm");
	const input=document.getElementById("check_number");
	const result=document.getElementById("result");

	form.addEventListener("submit", function(event){
		event.preventDefault();
	const value = input.value.trim();
	const message=checkNumber(value);

	result.textContent=message;
	result.style.display="block";

	if(message ==="Congratulations!"){
		input.style.border= "";
	}else{
		input.style.borderColor="red";
	}
	})
}