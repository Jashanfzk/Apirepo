function checkNumber(input) {
    // Add your code inside
	if(input ===""){
		return"Missing input";
	}
	const number = parseInt(input);
	
	if(isNaN(number)){
		return"Wrong Number";
	}
	if (number <=17 || number > 99){
		return "Wrong Number";
	}
	if (number >= 17 && number < 87){
		return "Your number is less than secret. Try again.";
	}
	if (number > 87 && number< 99){
		return "Your number is more than secret. Try again.";
	}
	if (number === 87){
		return"Congratulations!";
	}

		return "invalid input";

	

}

// Do not change below
if (typeof module !== 'undefined' && module.exports) {
    module.exports = checkNumber;
} else {
    window.checkNumber = checkNumber;
}