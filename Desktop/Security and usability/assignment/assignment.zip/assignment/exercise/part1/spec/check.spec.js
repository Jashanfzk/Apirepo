const checkNumber = require("./check.js"); // Do not change this line

describe('checkNumber', () => {
    // Create code for your tests below
it("return 'Missing input' for empty value", ()=>{
	expect(checkNumber("")).toBe("Missing input");
});
it("return 'Wrong Number' for input less than 17" , () => {
	expect(checkNumber("10")).toBe("Wrong Number");
})
it("return 'Wrong Number' for input more than 99",() => {
	expect(checkNumber("100")).toBe("Wrong Number");

})
it("return 'Your number is less than secret. Try again.' for 50",() => {
	expect(checkNumber("50")).toBe("Your number is less than secret. Try again.");    
	
})
it("return 'Your number is more than secret. Try again.' for 90",() => {
	expect(checkNumber("90")).toBe("Your number is more than secret. Try again.");
	
})
it("return, 'Congratulations!' for 87",() => {
	expect(checkNumber("87")).toBe("Congratulations!");
	
})
it("return 'Wrong Number' for non-numeric input 'abc'",() => {
	expect(checkNumber("abc")).toBe("Wrong Number");

});


it("return 'Wrong Number' for special characters'@#$%^'",() => {
	expect(checkNumber("10@#$%^")).toBe("Wrong Number");
})

it("return 'Wrong Number' for mixed '76cba'",() => {
	expect(checkNumber("76cba")).toBe("Wrong Number");
	
})

it("return 'Your number is more than secret. Try again.' for 86 ",() => {
	expect(checkNumber("86")).toBe("Your number is more than secret. Try again.");
	
})


});
